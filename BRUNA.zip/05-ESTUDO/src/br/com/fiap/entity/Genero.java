package br.com.fiap.entity;

public enum Genero {
	
	FEMININO, MASCULINO, OUTROS;

}
