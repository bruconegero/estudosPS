package br.com.fiap.entity;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@IdClass(CorridaPK.class)
@Entity
@Table(name="T_PS_CORRIDA")
@SequenceGenerator(name="corrida", sequenceName="T_SEQ_CORRIDA", allocationSize=1)
public class Corrida {
	
	@Id
	@Column(name="cd_corrida")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="corrida")
	private int codigo;
	
	@ManyToOne
	@JoinColumn(name="nr_carteira")
	private Motorista motorista;
	
	@ManyToOne
	@JoinColumn(name="cd_passageiro")
	private Passageiro passageiro;
	
	
	@Column(name="ds_origem", length=50)
	private String origem;
	
	@Column(name="ds_destino", length=50)
	private String destino;
	
	@Column(name="dt_corrida")
	@Temporal(TemporalType.DATE)
	private Calendar corrida;
	
	@Column(name="vl_corrida")
	private double valor;
	
	

}
