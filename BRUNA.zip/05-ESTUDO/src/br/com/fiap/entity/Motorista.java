package br.com.fiap.entity;


import java.util.Calendar;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity
@Table(name="T_PS_MOTORISTA")
public class Motorista {
	
	@Id
	@Column(name="nr_carteira")
	private int codigo;
	
	@OneToMany(mappedBy="motorista")
	private List<Corrida> corrida;
	
	@Column(name="nm_motorista", nullable= false, length=150)
	private String nome;
	
	@Column(name="dt_nasc")
	@Temporal(TemporalType.DATE)
	private Calendar dataNasc;
	
	@Column(name="fl_carteira")
	@Lob
	private byte[] foto;
	
	@Column(name="ds_genero")
	@Enumerated(EnumType.STRING)
	private Genero genero; 
	
	

}
