package br.com.fiap.entity;

import java.io.Serializable;

public class CorridaPK implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private int corrida;
	
	private int passageiro;
	
	private int motorista;
	
	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + corrida;
		result = prime * result + motorista;
		result = prime * result + passageiro;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CorridaPK other = (CorridaPK) obj;
		if (corrida != other.corrida)
			return false;
		if (motorista != other.motorista)
			return false;
		if (passageiro != other.passageiro)
			return false;
		return true;
	}

	public int getCorrida() {
		return corrida;
	}

	public void setCorrida(int corrida) {
		this.corrida = corrida;
	}

	public int getPassageiro() {
		return passageiro;
	}

	public void setPassageiro(int passageiro) {
		this.passageiro = passageiro;
	}

	public int getMotorista() {
		return motorista;
	}

	public void setMotorista(int motorista) {
		this.motorista = motorista;
	}
	
	
	
	

}
