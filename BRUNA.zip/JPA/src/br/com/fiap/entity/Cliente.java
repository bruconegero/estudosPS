package br.com.fiap.entity;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@Entity
@Table(name="T_CLIENTE")
@SequenceGenerator(name="cliente",sequenceName="T_SQ_CLIENTE",allocationSize=1)
public class Cliente {
	
	@Id
	@Column(name="CD_CLIENTE")
	@GeneratedValue(generator="cliente",strategy=GenerationType.SEQUENCE)
	private int codigo;
	
	@Column(name="NM_CLIENTE", length=50, nullable=false)
	private String nome;
	
	@Column(name="DT_NASC")
	//ESPECIFICO PARA CALENDAR 
	@Temporal(value=TemporalType.DATE)
	private Calendar dataNasc;
	
	@Column(name="DS_GENERO")
	//ESPECIFICO PARA ENUM 
	@Enumerated(value=EnumType.STRING)
	private Genero genero;
	
	//ATRIBUTO QUE NAO SERA MAPEADO NO BANCO DE DADOS
	@Transient
	private int chaveAcesso;
	
	
	
	//CRIAR OUTRO CONSTRUTOR CHEIO SEM A CHAVE PRIMARIA (CODIGO)
	public Cliente(String nome, Calendar dataNasc, Genero genero, int chaveAcesso) {
		super();
		this.nome = nome;
		this.dataNasc = dataNasc;
		this.genero = genero;
		this.chaveAcesso = chaveAcesso;
	}

	public Cliente() {
		super();
	}

	
	public Cliente(int codigo, String nome, Calendar dataNasc, Genero genero, int chaveAcesso) {
		super();
		this.codigo = codigo;
		this.nome = nome;
		this.dataNasc = dataNasc;
		this.genero = genero;
		this.chaveAcesso = chaveAcesso;
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Calendar getDataNasc() {
		return dataNasc;
	}

	public void setDataNasc(Calendar dataNasc) {
		this.dataNasc = dataNasc;
	}

	public Genero getGenero() {
		return genero;
	}

	public void setGenero(Genero genero) {
		this.genero = genero;
	}

	public int getChaveAcesso() {
		return chaveAcesso;
	}

	public void setChaveAcesso(int chaveAcesso) {
		this.chaveAcesso = chaveAcesso;
	}
	
	
	
	
	
	
	
	
	
	

}
