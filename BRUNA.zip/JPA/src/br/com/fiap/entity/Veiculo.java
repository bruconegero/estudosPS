package br.com.fiap.entity;

public class Veiculo {
	
	private int codigo;
	private String

}
