package br.com.fiap.teste;

import java.util.Calendar;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import br.com.fiap.entity.Cliente;
import br.com.fiap.entity.Genero;

class Teste {

	//ATRIBUTOS DA CLASSE TESTE
	private EntityManagerFactory fabrica;
	private EntityManager em;

	@BeforeAll
	void inicio() {
		fabrica= Persistence.createEntityManagerFactory("CLIENTE_ORACLE");
		em = fabrica.createEntityManager();
	}

	@Test
	void test() {
		Cliente cliente = new Cliente("Bruna",Calendar.getInstance(), Genero.FEMININO, 1);
		
		//s� quando n�o tiver o dao 
		em.getTransaction().begin();
		
		//inserindo o cliente (objeto) no banco de dados 
		em.persist(cliente);
		
		//confiamrndo o objeto no banco de dados 
		em.getTransaction().commit();
		
		em.close();
		fabrica.close();

	}

}
