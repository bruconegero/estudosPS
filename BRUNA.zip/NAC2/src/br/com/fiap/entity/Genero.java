package br.com.fiap.entity;

public enum Genero {
	
	//SEMPRE LETRA MAIUSCULA
	MASCULINO, FEMININO, OUTROS;

}
