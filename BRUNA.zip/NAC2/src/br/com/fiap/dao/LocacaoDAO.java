package br.com.fiap.dao;

import br.com.fiap.entity.Locacao;
import br.com.fiap.entity.LocacaoPK;

public interface LocacaoDAO extends GenericDAO<Locacao, LocacaoPK>{

	
}
