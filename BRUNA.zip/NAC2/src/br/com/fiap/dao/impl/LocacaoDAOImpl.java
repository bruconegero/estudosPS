package br.com.fiap.dao.impl;

import java.util.Calendar;
import java.util.List;

import br.com.fiap.dao.GenericDAO;
import br.com.fiap.entity.Locacao;

	public interface LocacaoDAO extends GenericDAO<Locacao, Locacao>{
		
		List<Locacao> buscarPorData(Calendar Inicio, Calendar fim);
		
		long contarPorCliente(int codigoCliente;)
	
}
