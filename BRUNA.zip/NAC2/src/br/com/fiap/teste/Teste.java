package br.com.fiap.teste;

import java.util.Calendar;

import javax.persistence.EntityManagerFactory;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import br.com.fiap.dao.LocacaoDAO;
import br.com.fiap.dao.impl.LocacaoDAOImpl;
import br.com.fiap.entity.Cliente;
import br.com.fiap.entity.Genero;
import br.com.fiap.singleton.EntityManagerFactorySingleton;

class Teste {
	
	private static LocacaoDAO dao;
	
	@BeforeAll
	public static void Localizar() {
		EntityManagerFactory fabrica = 
				EntityManagerFactorySingleton.getInstance();
		dao =  new LocacaoDAOImpl(fabrica.createEntityManager());
	}

	@Test
	void test() {
		Cliente cliente = new Cliente ("Bruna", Genero.FEMININO, Calendar.getInstance());
		Imovel imovel = new Imovel(null, "2 quartos", "Av. Paulista", 120121);
		Locacao locacao= new Locacao(cliente, imovel, Calendar.getInstance(), 3000);
		
		try {
			dao.cadastrar(locacao);
			dao.commit();
		} catch (Exception e) {
			e.printStackTrace();
			fail("Error");
		}
	}

}


